#ifndef TODOAPP_H
#define TODOAPP_H

#include <QMainWindow>
#include <QMainWindow>
#include <QTableWidget>
#include <QStandardItemModel>
#include <QAction>
#include <QMenu>
#include <QToolBar>
#include <QLabel>
#include <QStatusBar>
#include<iostream>
#include "QMessageBox"
#include "QSplitter"
#include "QHBoxLayout"
#include "QListView"
#include "QDir"
#include "QDate"
#include "QVBoxLayout"
#include "QGridLayout"

QT_BEGIN_NAMESPACE
namespace Ui { class toDoApp; }
QT_END_NAMESPACE

class toDoApp : public QMainWindow
{
    Q_OBJECT

public:
    toDoApp(QWidget *parent = nullptr);
   ~toDoApp();
private:
    Ui::toDoApp *ui;
    QStandardItemModel* m1;
    QStandardItemModel* m2;
    QStandardItemModel* m3;


protected:
    void setUpMainWidget();
    void createActions();
    void makeConnexions();
    void createMenus();
    void createToolbars();
    void closeEvent(QCloseEvent *e) override;
    void dropEvent(QDropEvent *e) override;

private slots:
    void quit();
    void NewTask();
    void aboutslot();
    void aboutQtslot();
    void ClearSlot();


    void PendingSlot();
    void CompletedSlot();
private:


    QMenu *fileMenu;
    QMenu *optionsMenu;
    QMenu *HelpMenu;
    QMenu *toolsMenu;
private:
    QAction *newtask;
    QAction *completed;
    QAction *pending;
    QAction *about;
    QAction *aboutQt;
    QAction *Close;
    QAction *Clear;

private:
    QStringList pesistent;
    QStringList Pending;
    QStringList Completed;

};
#endif // TODOAPP_H
