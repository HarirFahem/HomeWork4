#include "todoapp.h"
#include "ui_todoapp.h"
#include "dialog1.h"
#include<QStringListModel>
#include<QTextStream>
#include<QApplication>
#include<QFile>

toDoApp::toDoApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::toDoApp)
{
    ui->setupUi(this);
    setUpMainWidget();
    createActions();
    makeConnexions();
    createToolbars();
    createMenus();
    setWindowTitle("ToDoApp");

    m1 = new QStandardItemModel();
    m2 = new QStandardItemModel();
    m3 = new QStandardItemModel();


    QFile file("/Users/wafa harir/Downloads/save.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!file.atEnd()) {
        QString line = file.readLine();
        QStandardItem *tmp = new QStandardItem();


        if(line.at(0)== "1"){

            pesistent.append(line);
            tmp->setIcon(QIcon(":/newtask_icon.png"));
            tmp->setText(line+" ");

            m1->appendRow(tmp);

            ui->pesistent->setModel(m1);
        }else if(line.at(0)== "2"){

            Pending.append(line);
            tmp->setIcon(QIcon(":/pending_icon.png"));
            tmp->setText(line+" ");

            m2->appendRow(tmp);

            ui->Pending->setModel(m2);
        }else if(line.at(0)== "3"){
            Completed.append(line);


            tmp->setIcon(QIcon(":/completed_icon.png"));
            tmp->setText(line+" ");

            m3->appendRow(tmp);

            ui->Completed->setModel(m3);
        }
    }


}




toDoApp::~toDoApp()
{
    delete ui;
    delete newtask;
    delete pending;
    delete completed;
    delete about;
    delete aboutQt;
    delete Close;

    delete fileMenu;
    delete HelpMenu;
    delete optionsMenu;
    delete toolsMenu;
    delete Clear;
}
void toDoApp::createActions()
{

  QPixmap newIcon(":/newtask_icon.png");
  newtask= new QAction(newIcon,"&New",this);
  newtask->setShortcut(tr("CTRL+N"));

  QPixmap pendingIcon(":/pending_icon.png");
  pending= new QAction(pendingIcon,"&Pending",this);

  QPixmap completedIcon(":/completed_icon.png");

  completed= new QAction(completedIcon,"&Completed",this);

  QPixmap aboutIcon(":/about_icon.png");
  about= new QAction(aboutIcon,"&About",this);
  QPixmap aboutQtIcon(":/aboutQt_icon.png");
  aboutQt= new QAction(aboutQtIcon,"&AboutQt",this);

  QPixmap closeIcon(":/close_icon.png");
  Close= new QAction(closeIcon,"&Close",this);
  Close->setShortcut(tr("F5"));
  QPixmap clearIcon(":/clearicon.png");
  Clear= new QAction(clearIcon,"&Clear",this);
  Clear->setShortcut(tr("F7"));

}

void toDoApp::createMenus()
{
    fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction(newtask);
    fileMenu->addAction(Close);

    optionsMenu = menuBar()->addMenu("&Options");
    optionsMenu->addAction(Clear);
    optionsMenu->addAction(completed);
    optionsMenu->addAction(pending);

    HelpMenu= menuBar()->addMenu("&Help");
    HelpMenu->addAction(about);
    HelpMenu->addAction(aboutQt);
}
void toDoApp::createToolbars()
{

        auto toolbar1 = addToolBar("File");
        toolbar1->addAction(newtask);
        toolbar1->addAction(Close);
        auto toolbar2 = addToolBar("Options");
        toolbar2->addAction(Clear);
        toolbar2->addAction(pending);
        toolbar2->addAction(completed);
}
void toDoApp::makeConnexions()
{
    connect(Close,&QAction::triggered,this,&toDoApp::quit);
    connect(Clear,&QAction::triggered,this,&toDoApp::ClearSlot);
    connect(newtask,&QAction::triggered,this,&toDoApp::NewTask);
    connect(about,&QAction::triggered,this,&toDoApp::aboutslot);
    connect(aboutQt,&QAction::triggered,this,&toDoApp::aboutQtslot);
    connect(pending,&QAction::triggered,this,&toDoApp::PendingSlot);
    connect(completed,&QAction::triggered,this,&toDoApp::CompletedSlot);

}
void toDoApp::setUpMainWidget()
{

    ui->Pending->setVisible(false);
    ui->Completed->setVisible(false);
    ui->Pending->setDragDropMode(QAbstractItemView::DragDrop);
    ui->pesistent->setDragDropMode(QAbstractItemView::DragDrop);
    ui->Completed->setDragDropMode(QAbstractItemView::DragDrop);
    ui->Pending->setDefaultDropAction(Qt::MoveAction);
    ui->Completed->setDefaultDropAction(Qt::MoveAction);
    ui->pesistent->setDefaultDropAction(Qt::MoveAction);


}



void toDoApp::quit(){
    auto reply = QMessageBox::question(this, "Exit","Do you really want to quit?");
    if(reply == QMessageBox::Yes)
        qApp->exit();
}
void toDoApp::NewTask()
{

    Dialog1 dialog;
    auto replu = dialog.exec();
    if(replu==Dialog1::Accepted){
        QString text = dialog.getText();
        QStandardItem *tmp = new QStandardItem;


        if(dialog.getDate()==QDate::currentDate() && !dialog.isChecked()){
            tmp->setIcon(QIcon(":/Todayicon.png"));
            tmp->setText("1 "+text+" ");

            m1->appendRow(tmp);

            ui->pesistent->setModel(m1);
            pesistent.append(text);


        }
        else if(dialog.getDate()!=QDate::currentDate() && !dialog.isChecked()){

            tmp->setIcon(QIcon(":/pending_icon.png"));
            tmp->setText("2 "+text+" ");

            m2->appendRow(tmp);

            ui->Pending->setModel(m2);
            Pending.append(text);


        }
        else if(dialog.isChecked()){


            tmp->setIcon(QIcon(":/completed_icon.png"));
            tmp->setText("3 "+text+" ");

            m3->appendRow(tmp);

            ui->Completed->setModel(m3);
            Completed.append(text);


        }
    }


}
void toDoApp::aboutslot()
{
    QMessageBox::about(this,"about","to do app is an app to manage tasks");
}
void toDoApp::aboutQtslot()
{
    QMessageBox::aboutQt(this,"Your Qt");
}

void toDoApp::PendingSlot(){
    if(ui->Pending->isVisible()){
        ui->Pending->hide();
}else{
   ui->Pending->show();
    }
}

void toDoApp::CompletedSlot(){
    if(ui->Completed->isVisible()){
        ui->Completed->hide();
}else{
   ui->Completed->show();
    }
}



void toDoApp::closeEvent(QCloseEvent *e){

    QFile file("/Users/wafa harir/Downloads/save.txt");
    if (file.open(QIODevice::ReadWrite| QIODevice::Text)){

        QTextStream out(&file);
        for (int i=0;i<pesistent.size() ;i++ ) {
            out<< "1"<< pesistent[i] << Qt::endl;
        }
        for (int i=0;i<Pending.size() ;i++ ) {
            out<< "2"<< Pending[i] << Qt::endl;
        }
        for (int i=0;i<Completed.size() ;i++ ) {
            out<< "3"<< Completed[i] << Qt::endl;
        }
        file.close();
    }
}




void toDoApp::dropEvent(QDropEvent *e){
    Dialog1 dialog;
    auto reply= dialog.exec();
}


void toDoApp::ClearSlot()
{



    QFile file("/Users/wafa harir/Downloads/save.txt");
    if (file.open(QIODevice::ReadWrite| QIODevice::Text)){
        file.resize(0);

    }
}

