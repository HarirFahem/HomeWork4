#include "todoapp.h"
#include "ui_todoapp.h"
#include "dialog1.h"
#include<QStringListModel>
#include<QTextStream>
#include<QApplication>
#include<QFile>


toDoApp::toDoApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::toDoApp)
{

    ui->setupUi(this);
    setUpMainWidget();
    createActions();
    makeConnexions();
    createToolbars();
    createMenus();
    setWindowTitle("ToDoApp");


    QFile file("/Users/hp/Desktop/save.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    while (!file.atEnd()) {
        QString line = file.readLine();
        if(line.at(0)== "1"){
            ui->pesistent->addItem(line.mid(1,line.size()));
        }else if(line.at(0)== "2"){
             ui->Pending->addItem(line.mid(1,line.size()));
        }else if(line.at(0)== "3"){
            ui->completed->addItem(line.mid(1,line.size()));

        }
    }

}




toDoApp::~toDoApp()
{
    delete ui;
    delete newtask;
    delete pending;
    delete completed;
    delete about;
    delete aboutQt;
    delete Close;

    delete fileMenu;
    delete HelpMenu;
    delete optionsMenu;
    delete toolsMenu;
    delete Clear;
}
void toDoApp::createActions()
{

  QPixmap newIcon(":/newtask_icon.png");
  newtask= new QAction(newIcon,"&New",this);
  newtask->setShortcut(tr("CTRL+N"));

  QPixmap pendingIcon(":/pending_icon.png");
  pending= new QAction(pendingIcon,"&Pending",this);

  QPixmap completedIcon(":/completed_icon.png");

  completed= new QAction(completedIcon,"&Completed",this);

  QPixmap aboutIcon(":/about_icon.png");
  about= new QAction(aboutIcon,"&About",this);
  QPixmap aboutQtIcon(":/aboutQt_icon.png");
  aboutQt= new QAction(aboutQtIcon,"&AboutQt",this);

  QPixmap closeIcon(":/close_icon.png");
  Close= new QAction(closeIcon,"&Close",this);
  Close->setShortcut(tr("F5"));
  QPixmap clearIcon(":/clearicon.png");
  Clear= new QAction(clearIcon,"&Clear",this);
  Clear->setShortcut(tr("F7"));

}

void toDoApp::createMenus()
{
    fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction(newtask);
    fileMenu->addAction(Close);

    optionsMenu = menuBar()->addMenu("&Options");
    optionsMenu->addAction(Clear);
    optionsMenu->addAction(completed);
    optionsMenu->addAction(pending);

    HelpMenu= menuBar()->addMenu("&Help");
    HelpMenu->addAction(about);
    HelpMenu->addAction(aboutQt);
}
void toDoApp::createToolbars()
{

        auto toolbar1 = addToolBar("File");
        toolbar1->addAction(newtask);
        toolbar1->addAction(Close);
        auto toolbar2 = addToolBar("Options");
        toolbar2->addAction(Clear);
        toolbar2->addAction(pending);
        toolbar2->addAction(completed);
}
void toDoApp::makeConnexions()
{
    connect(Close,&QAction::triggered,this,&toDoApp::quit);
    connect(Clear,&QAction::triggered,this,&toDoApp::ClearSlot);
    connect(newtask,&QAction::triggered,this,&toDoApp::NewTask);
    connect(about,&QAction::triggered,this,&toDoApp::aboutslot);
    connect(aboutQt,&QAction::triggered,this,&toDoApp::aboutQtslot);
    connect(pending,&QAction::triggered,this,&toDoApp::PendingSlot);
    connect(completed,&QAction::triggered,this,&toDoApp::CompletedSlot);

    connect(ui->pesistent,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(Firsttask()));
    connect(ui->Pending,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(secondtask()));
    connect(ui->completed,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(thirdtask()));
}
void toDoApp::setUpMainWidget()
{



    ui->Pending->setVisible(false);
    ui->completed->setVisible(false);
    ui->Pending->setDragDropMode(QAbstractItemView::DragDrop);
    ui->pesistent->setDragDropMode(QAbstractItemView::DragDrop);
    ui->completed->setDragDropMode(QAbstractItemView::DragDrop);
    ui->Pending->setDefaultDropAction(Qt::MoveAction);
    ui->completed->setDefaultDropAction(Qt::MoveAction);
    ui->pesistent->setDefaultDropAction(Qt::MoveAction);


}


void toDoApp::quit(){
    auto reply = QMessageBox::question(this, "Exit","Do you really want to quit?");
    if(reply == QMessageBox::Yes)
        qApp->exit();
}
void toDoApp::NewTask()
{

    Dialog1 dialog;
    auto replu = dialog.exec();
    if(replu==Dialog1::Accepted){
        QString text = dialog.getText();
        if(dialog.getDate()==QDate::currentDate() && !dialog.isChecked()){
            QIcon TodayIcon(":/Todayicon.png");

            ui->pesistent->addItem(new QListWidgetItem(TodayIcon,text));
        }
        else if(dialog.getDate()!=QDate::currentDate() && !dialog.isChecked()){
            QIcon pendingIcon(":/pending_icon.png");

            ui->Pending->addItem(new QListWidgetItem(pendingIcon,text));
        }
        else if(dialog.isChecked()){
            QIcon completedIcon(":/completed_icon.png");

            ui->completed->addItem(new QListWidgetItem(completedIcon,text));
        }
    }


}
void toDoApp::aboutslot()
{
    QMessageBox::about(this,"about","to do app is an app to manage tasks");
}
void toDoApp::aboutQtslot()
{
    QMessageBox::aboutQt(this,"Your Qt");
}

void toDoApp::PendingSlot(){
    if(ui->Pending->isVisible()){
        ui->Pending->hide();
}else{
   ui->Pending->show();
    }
}

void toDoApp::CompletedSlot(){
    if(ui->completed->isVisible()){
        ui->completed->hide();
}else{
   ui->completed->show();
    }
}



void toDoApp::closeEvent(QCloseEvent *e){

    QFile file("/Users/hp/Desktop/save.txt");
    if (file.open(QIODevice::ReadWrite| QIODevice::Text)){

        QTextStream out(&file);
        for (int i=0;i<ui->pesistent->count() ;i++ ) {
            out<< "1"<< ui->pesistent->item(i)->text() << Qt::endl;
        }
        for (int i=0;i<ui->Pending->count() ;i++ ) {
            out<< "2"<< ui->pesistent->item(i)->text() << Qt::endl;
        }
        for (int i=0;i<ui->completed->count() ;i++ ) {
            out<< "3"<< ui->pesistent->item(i)->text() << Qt::endl;
        }
        file.close();
    }
}




void toDoApp::dropEvent(QDropEvent *e){
    Dialog1 dialog;
    auto reply= dialog.exec();
}


void toDoApp::ClearSlot()
{
    ui->Pending->clear();
    ui->pesistent->clear();
    ui->completed->clear();

    QFile file("/Users/hp/Desktop/save.txt");
    if (file.open(QIODevice::ReadWrite| QIODevice::Text)){
        file.resize(0);

    }
}

